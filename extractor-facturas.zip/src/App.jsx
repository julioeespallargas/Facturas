import React, { useState, useRef, useCallback, useEffect } from "react";

const CATEGORIES = ["Moto 4", "Talent", "Conjunto", "Estructura"];
const HEADERS = ["Proveedor", "Nº Factura", "Fecha", "Concepto", "Cantidad", "Importe", "Categoría", "Total Factura"];
const KEY_STORE = "anthropic_api_key";

export default function App() {
  const [apiKey, setApiKey] = useState("");
  const [keySaved, setKeySaved] = useState(false);
  const [files, setFiles] = useState([]);
  const [rows, setRows] = useState([]);
  const [status, setStatus] = useState("idle"); // idle | processing | done
  const [progress, setProgress] = useState({ done: 0, total: 0 });
  const [errorMsg, setErrorMsg] = useState("");
  const [copied, setCopied] = useState(false);
  const [showText, setShowText] = useState(false);
  const inputRef = useRef(null);
  const textRef = useRef(null);

  useEffect(() => {
    const saved = localStorage.getItem(KEY_STORE);
    if (saved) {
      setApiKey(saved);
      setKeySaved(true);
    }
  }, []);

  const saveKey = () => {
    const k = apiKey.trim();
    if (!k) return;
    localStorage.setItem(KEY_STORE, k);
    setKeySaved(true);
  };
  const clearKey = () => {
    localStorage.removeItem(KEY_STORE);
    setApiKey("");
    setKeySaved(false);
  };

  const fileToBase64 = (file) =>
    new Promise((res, rej) => {
      const r = new FileReader();
      r.onload = () => res(r.result.split(",")[1]);
      r.onerror = () => rej(new Error("No se pudo leer el archivo"));
      r.readAsDataURL(file);
    });

  const buildContentBlock = async (file) => {
    const data = await fileToBase64(file);
    if (file.type === "application/pdf") {
      return { type: "document", source: { type: "base64", media_type: "application/pdf", data } };
    }
    return { type: "image", source: { type: "base64", media_type: file.type || "image/jpeg", data } };
  };

  const extractOne = async (file) => {
    const block = await buildContentBlock(file);
    const prompt = `Eres un extractor de datos de facturas. Analiza la factura adjunta y devuelve EXCLUSIVAMENTE un objeto JSON válido (sin texto adicional, sin markdown, sin backticks) con esta estructura exacta:

{
  "proveedor": "nombre del emisor de la factura",
  "numero_factura": "número de factura",
  "fecha": "DD/MM/AAAA",
  "lineas": [
    { "concepto": "descripción del artículo o servicio", "cantidad": número, "importe": número (total de esa línea, sin símbolo de moneda, con punto decimal) }
  ],
  "base_imponible": número,
  "iva": número,
  "total": número
}

Reglas:
- Una entrada en "lineas" por cada concepto desglosado de la factura.
- "importe" es el total de la línea, número con punto decimal, sin símbolos.
- Si un dato no aparece, usa "" para texto o 0 para números.
- "fecha" siempre en formato DD/MM/AAAA.
- Responde solo con el JSON.`;

    const response = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-key": apiKey.trim(),
        "anthropic-version": "2023-06-01",
        "anthropic-dangerous-direct-browser-access": "true",
      },
      body: JSON.stringify({
        model: "claude-sonnet-4-6",
        max_tokens: 1500,
        messages: [{ role: "user", content: [block, { type: "text", text: prompt }] }],
      }),
    });

    if (!response.ok) {
      const err = await response.json().catch(() => ({}));
      throw new Error(err?.error?.message || `Error ${response.status}`);
    }

    const json = await response.json();
    const text = (json.content || [])
      .filter((i) => i.type === "text")
      .map((i) => i.text)
      .join("\n")
      .replace(/```json|```/g, "")
      .trim();

    return { ...JSON.parse(text), _file: file.name };
  };

  const flatten = (inv) => {
    const lineas = Array.isArray(inv.lineas) && inv.lineas.length ? inv.lineas : [{ concepto: "", cantidad: "", importe: "" }];
    return lineas.map((l) => ({
      proveedor: inv.proveedor || "",
      numero: inv.numero_factura || "",
      fecha: inv.fecha || "",
      concepto: l.concepto || "",
      cantidad: l.cantidad ?? "",
      importe: l.importe ?? "",
      categoria: "",
      total: inv.total ?? "",
    }));
  };

  const process = useCallback(
    async (fileList) => {
      const arr = Array.from(fileList);
      if (!arr.length) return;
      if (!apiKey.trim()) {
        setErrorMsg("Introduce tu clave de API de Anthropic antes de subir facturas.");
        return;
      }
      setFiles(arr);
      setStatus("processing");
      setErrorMsg("");
      setShowText(false);
      setRows([]);
      setProgress({ done: 0, total: arr.length });
      const collected = [];
      for (let i = 0; i < arr.length; i++) {
        try {
          collected.push(...flatten(await extractOne(arr[i])));
        } catch (e) {
          collected.push({
            proveedor: "ERROR", numero: "", fecha: "", concepto: `${arr[i].name}: ${e.message}`,
            cantidad: "", importe: "", categoria: "", total: "",
          });
        }
        setProgress({ done: i + 1, total: arr.length });
        setRows([...collected]);
      }
      setStatus("done");
    },
    [apiKey]
  );

  const onDrop = (e) => {
    e.preventDefault();
    if (e.dataTransfer.files?.length) process(e.dataTransfer.files);
  };

  const setCategoria = (idx, val) =>
    setRows((r) => r.map((row, i) => (i === idx ? { ...row, categoria: val } : row)));

  const tsv = () => {
    const lines = [HEADERS.join("\t")];
    rows.forEach((r) =>
      lines.push([r.proveedor, r.numero, r.fecha, r.concepto, r.cantidad, r.importe, r.categoria, r.total].join("\t"))
    );
    return lines.join("\n");
  };

  const copyAll = async () => {
    const data = tsv();
    try {
      await navigator.clipboard.writeText(data);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
      return;
    } catch {}
    try {
      const ta = document.createElement("textarea");
      ta.value = data;
      ta.style.position = "fixed";
      ta.style.opacity = "0";
      document.body.appendChild(ta);
      ta.select();
      const ok = document.execCommand("copy");
      document.body.removeChild(ta);
      if (ok) {
        setCopied(true);
        setTimeout(() => setCopied(false), 2000);
        return;
      }
      throw new Error();
    } catch {
      setShowText(true);
    }
  };

  const downloadCsv = () => {
    const sep = ";";
    const esc = (v) => {
      const s = String(v ?? "");
      return /[";\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
    };
    const lines = [HEADERS.map(esc).join(sep)];
    rows.forEach((r) =>
      lines.push([r.proveedor, r.numero, r.fecha, r.concepto, r.cantidad, r.importe, r.categoria, r.total].map(esc).join(sep))
    );
    const blob = new Blob(["\uFEFF" + lines.join("\r\n")], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "facturas.csv";
    a.click();
    URL.revokeObjectURL(url);
  };

  const selectAllText = () => {
    if (textRef.current) {
      textRef.current.focus();
      textRef.current.select();
    }
  };

  const reset = () => {
    setFiles([]); setRows([]); setStatus("idle"); setProgress({ done: 0, total: 0 });
    setErrorMsg(""); setShowText(false);
  };

  const validRows = rows.filter((r) => r.proveedor !== "ERROR");
  const totalImporte = validRows.reduce((s, r) => s + (parseFloat(r.importe) || 0), 0);

  return (
    <div className="wrap">
      <div className="topbar">
        <div className="brand">
          <div className="brand-mark">AK</div>
          <div>
            <div className="brand-name">Extractor de facturas</div>
            <div className="brand-sub">Aspar KSB · Administración</div>
          </div>
        </div>
        <a className="ghostlink" href="https://console.anthropic.com/settings/keys" target="_blank" rel="noreferrer">
          Obtener clave API ↗
        </a>
      </div>

      <main className="main">
        {/* API KEY */}
        <section className="card keycard">
          <div className="key-row">
            <div className="key-label">
              <span className="dot" data-on={keySaved} />
              Clave de API de Anthropic
              <span className="key-note">se guarda solo en este navegador</span>
            </div>
            <div className="key-input-row">
              <input
                type="password"
                className="input"
                placeholder="sk-ant-..."
                value={apiKey}
                onChange={(e) => { setApiKey(e.target.value); setKeySaved(false); }}
                autoComplete="off"
              />
              {keySaved ? (
                <button className="btn btn-ghost" onClick={clearKey}>Borrar</button>
              ) : (
                <button className="btn btn-navy" onClick={saveKey}>Guardar</button>
              )}
            </div>
          </div>
        </section>

        {/* HERO / DROP */}
        {status === "idle" && (
          <section
            className="card dropzone"
            onClick={() => inputRef.current?.click()}
            onDragOver={(e) => e.preventDefault()}
            onDrop={onDrop}
          >
            <div className="drop-plus">+</div>
            <h2 className="drop-title">Arrastra tus facturas aquí</h2>
            <p className="drop-hint">PDF, JPG o PNG · varias a la vez · clic para seleccionar</p>
            <input
              ref={inputRef}
              type="file"
              accept="application/pdf,image/*"
              multiple
              hidden
              onChange={(e) => process(e.target.files)}
            />
          </section>
        )}

        {status === "processing" && (
          <section className="card processing">
            <div className="spinner" />
            <div className="proc-text">Leyendo factura {progress.done} de {progress.total}</div>
            <div className="bar-track">
              <div className="bar-fill" style={{ width: `${(progress.done / progress.total) * 100}%` }} />
            </div>
          </section>
        )}

        {errorMsg && <div className="banner-error">{errorMsg}</div>}

        {rows.length > 0 && (
          <section className="results">
            <div className="toolbar">
              <div className="stats">
                <div className="stat">
                  <div className="stat-num">{validRows.length}</div>
                  <div className="stat-lbl">líneas</div>
                </div>
                <div className="stat-sep" />
                <div className="stat">
                  <div className="stat-num">{totalImporte.toFixed(2)} €</div>
                  <div className="stat-lbl">importe total</div>
                </div>
              </div>
              <div className="actions">
                <button className="btn btn-ghost" onClick={reset}>Reiniciar</button>
                <button className="btn btn-ghost" onClick={downloadCsv}>Descargar CSV</button>
                <button className="btn btn-magenta" onClick={copyAll}>
                  {copied ? "✓ Copiado" : "Copiar para Excel"}
                </button>
              </div>
            </div>

            <div className="card table-card">
              <div className="table-scroll">
                <table>
                  <thead>
                    <tr>{HEADERS.map((h) => <th key={h}>{h}</th>)}</tr>
                  </thead>
                  <tbody>
                    {rows.map((r, i) => (
                      <tr key={i} className={r.proveedor === "ERROR" ? "row-error" : ""}>
                        <td>{r.proveedor}</td>
                        <td className="mono">{r.numero}</td>
                        <td className="mono">{r.fecha}</td>
                        <td className="wide">{r.concepto}</td>
                        <td className="num">{r.cantidad}</td>
                        <td className="num">{typeof r.importe === "number" ? r.importe.toFixed(2) : r.importe}</td>
                        <td>
                          <select value={r.categoria} onChange={(e) => setCategoria(i, e.target.value)} className="select">
                            <option value="">—</option>
                            {CATEGORIES.map((c) => <option key={c} value={c}>{c}</option>)}
                          </select>
                        </td>
                        <td className="num">{typeof r.total === "number" ? r.total.toFixed(2) : r.total}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            {showText && (
              <div className="card fallback">
                <div className="fallback-title">Copia manual · selecciona todo y copia (Ctrl+C), luego pega en Excel</div>
                <textarea ref={textRef} readOnly value={tsv()} onFocus={selectAllText} className="textarea" />
                <button className="btn btn-ghost" onClick={selectAllText}>Seleccionar todo</button>
              </div>
            )}
          </section>
        )}
      </main>

      <footer className="footer">
        Las facturas se procesan en tu navegador con tu propia clave. Nada se almacena en ningún servidor.
      </footer>

      <StyleTag />
    </div>
  );
}

function StyleTag() {
  return (
    <style>{`
      .wrap { min-height:100%; display:flex; flex-direction:column; }
      .topbar {
        display:flex; align-items:center; justify-content:space-between;
        padding:16px 24px; border-bottom:1px solid var(--line); background:var(--paper);
      }
      .brand { display:flex; align-items:center; gap:12px; }
      .brand-mark {
        width:38px; height:38px; border-radius:9px; background:var(--navy); color:#fff;
        font-family:"Space Grotesk",sans-serif; font-weight:700; font-size:15px;
        display:flex; align-items:center; justify-content:center; letter-spacing:-0.02em;
      }
      .brand-name { font-family:"Space Grotesk",sans-serif; font-weight:600; font-size:15px; color:var(--navy); }
      .brand-sub { font-size:12px; color:var(--muted); margin-top:1px; }
      .ghostlink { font-size:13px; color:var(--navy); text-decoration:none; font-weight:500; }
      .ghostlink:hover { color:var(--magenta); }

      .main { flex:1; width:100%; max-width:1080px; margin:0 auto; padding:28px 24px 40px; }
      .card { background:var(--paper); border:1px solid var(--line); border-radius:var(--radius); box-shadow:var(--shadow); }

      .keycard { padding:18px 20px; margin-bottom:18px; animation:rise .3s ease; }
      .key-row { display:flex; flex-direction:column; gap:12px; }
      .key-label { display:flex; align-items:center; gap:8px; font-size:13px; font-weight:600; color:var(--ink); }
      .key-note { font-weight:400; color:var(--muted); font-size:12px; }
      .dot { width:8px; height:8px; border-radius:50%; background:#cbd0dc; }
      .dot[data-on="true"] { background:#22c55e; box-shadow:0 0 0 3px rgba(34,197,94,.15); }
      .key-input-row { display:flex; gap:10px; }
      .input {
        flex:1; padding:10px 13px; border:1px solid var(--line); border-radius:9px;
        font-size:14px; color:var(--ink); background:#fff; outline:none; transition:border-color .15s;
        font-family:"Inter",sans-serif;
      }
      .input:focus { border-color:var(--navy); box-shadow:0 0 0 3px rgba(11,30,110,.08); }

      .btn { border:none; border-radius:9px; padding:10px 16px; font-size:13.5px; font-weight:600; transition:transform .06s, background .15s; }
      .btn:active { transform:translateY(1px); }
      .btn-navy { background:var(--navy); color:#fff; }
      .btn-navy:hover { background:var(--navy-700); }
      .btn-magenta { background:var(--magenta); color:#fff; }
      .btn-magenta:hover { filter:brightness(.95); }
      .btn-ghost { background:#fff; color:var(--ink); border:1px solid var(--line); }
      .btn-ghost:hover { border-color:#c9cede; }

      .dropzone {
        padding:64px 24px; text-align:center; cursor:pointer; animation:rise .35s ease;
        border-style:dashed; border-color:#d3d8e6; transition:border-color .2s, background .2s;
      }
      .dropzone:hover { border-color:var(--navy); background:#fcfcff; }
      .drop-plus {
        width:52px; height:52px; margin:0 auto 18px; border-radius:14px; background:var(--navy);
        color:#fff; font-size:30px; font-weight:300; line-height:52px;
      }
      .drop-title { font-family:"Space Grotesk",sans-serif; font-size:20px; font-weight:600; color:var(--navy); margin:0; }
      .drop-hint { font-size:13.5px; color:var(--muted); margin-top:8px; }

      .processing { padding:52px 24px; text-align:center; animation:rise .3s ease; }
      .spinner { width:34px; height:34px; margin:0 auto 18px; border:3px solid var(--line); border-top-color:var(--magenta); border-radius:50%; animation:spin .8s linear infinite; }
      .proc-text { font-size:15px; font-weight:600; color:var(--navy); }
      .bar-track { width:260px; height:6px; background:var(--line); border-radius:4px; margin:16px auto 0; overflow:hidden; }
      .bar-fill { height:100%; background:var(--magenta); transition:width .3s ease; }

      .banner-error { background:#fdeef4; color:#b3145d; border:1px solid #f6c9de; padding:12px 16px; border-radius:10px; font-size:13.5px; margin-bottom:16px; }

      .results { animation:rise .3s ease; }
      .toolbar { display:flex; align-items:center; justify-content:space-between; flex-wrap:wrap; gap:16px; margin-bottom:16px; }
      .stats { display:flex; align-items:center; gap:20px; }
      .stat-num { font-family:"Space Grotesk",sans-serif; font-size:22px; font-weight:700; color:var(--navy); line-height:1; }
      .stat-lbl { font-size:11.5px; color:var(--muted); text-transform:uppercase; letter-spacing:.05em; margin-top:5px; }
      .stat-sep { width:1px; height:34px; background:var(--line); }
      .actions { display:flex; gap:10px; flex-wrap:wrap; }

      .table-card { overflow:hidden; }
      .table-scroll { overflow-x:auto; }
      table { width:100%; border-collapse:collapse; font-size:13.5px; }
      th {
        text-align:left; padding:12px 14px; background:#fafbfd; font-size:11px; font-weight:700;
        letter-spacing:.05em; text-transform:uppercase; color:var(--muted);
        border-bottom:1px solid var(--line); white-space:nowrap; position:sticky; top:0;
      }
      td { padding:11px 14px; border-bottom:1px solid #f1f3f8; vertical-align:top; white-space:nowrap; color:var(--ink); }
      tbody tr:last-child td { border-bottom:none; }
      tbody tr:hover td { background:#fcfcff; }
      .wide { white-space:normal; min-width:220px; max-width:360px; }
      .num { text-align:right; font-variant-numeric:tabular-nums; }
      .mono { font-variant-numeric:tabular-nums; color:var(--muted); }
      .row-error td { background:#fdeef4 !important; color:#b3145d; }
      .select { border:1px solid var(--line); border-radius:8px; padding:5px 8px; font-size:13px; background:#fff; font-family:inherit; cursor:pointer; }
      .select:focus { outline:none; border-color:var(--navy); }

      .fallback { padding:18px 20px; margin-top:16px; }
      .fallback-title { font-size:13px; color:var(--muted); margin-bottom:10px; }
      .textarea { width:100%; min-height:160px; padding:14px; font-size:12.5px; font-family:ui-monospace,monospace; border:1px solid var(--line); border-radius:10px; resize:vertical; margin-bottom:10px; color:var(--ink); }

      .footer { text-align:center; font-size:12px; color:var(--muted); padding:20px; border-top:1px solid var(--line); }

      @media (max-width:640px) {
        .toolbar { flex-direction:column; align-items:flex-start; }
        .actions { width:100%; }
        .actions .btn { flex:1; }
      }
    `}</style>
  );
}
